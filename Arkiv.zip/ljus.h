#ifndef LJUS_H
#define LJUS_H

float light_sensor(void);
void servo(int deg);
void sun_position(void);
extern  int sun_pos;


#endif