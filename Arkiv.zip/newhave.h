#ifndef NEWHAVE_H
#define NEWHAVE_H


unsigned char Read_Status_Display(void);

void Write_Command_2_Display(unsigned char Command);

void Write_Data_2_Display(unsigned char Data);
void Init_Display(void);


#endif