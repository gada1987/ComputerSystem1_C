#ifndef KEY_PAD_H
#define KEY_PAD_H

int key_pad(void);

#endif